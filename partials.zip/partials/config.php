<?php
$connect = mysqli_connect("localhost","register","register","zeitgeist");?>